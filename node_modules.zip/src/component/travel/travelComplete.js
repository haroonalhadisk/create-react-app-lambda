const TravelComplete=()=>
<button>Visited</button>

export default TravelComplete