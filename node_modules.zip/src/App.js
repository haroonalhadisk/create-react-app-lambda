import logo from './logo.svg';
import './App.css';
import TravelList from './component/travel/travellist';

function App() {
  return (
<div className="App">
      <TravelList /> 
      
    </div>
  );
}

export default App;

